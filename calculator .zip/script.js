const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");

let expression = "";

function updateDisplay() {
  display.value = expression;
}

buttons.forEach((btn) => {
  btn.addEventListener("click", () => {
    const action = btn.getAttribute("data-action");

    if (action === "clear") {
      expression = "";
    } else if (action === "=") {
      try {
        expression = eval(expression).toString();
      } catch {
        expression = "Error";
      }
    } else if (action === "back") {
      expression = expression.slice(0, -1);
    } else {
      expression += action;
    }

    updateDisplay();
  });
});

// Bonus: Keyboard support
document.addEventListener("keydown", (e) => {
  if ((e.key >= "0" && e.key <= "9") || "+-*/.".includes(e.key)) {
    expression += e.key;
  } else if (e.key === "Enter") {
    try {
      expression = eval(expression).toString();
    } catch {
      expression = "Error";
    }
  } else if (e.key === "Backspace") {
    expression = expression.slice(0, -1);
  } else if (e.key === "Escape") {
    expression = "";
  }
  updateDisplay();
});
